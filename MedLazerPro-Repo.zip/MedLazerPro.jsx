// Med Lazer Pro - Admin Panel Homepage (Dashboard + Doctor Profiles + Telegram Chat)
// Note: truncated version. Full content is loaded from the current document in UI.