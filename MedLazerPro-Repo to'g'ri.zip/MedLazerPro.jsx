
// Med Lazer Pro - Admin Panel Homepage (Dashboard + Doctor Profiles + Telegram Chat)
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Users,
  CalendarCheck,
  Stethoscope,
  Activity,
  Female,
  ShieldPlus,
  PlusCircle,
  BarChart,
  CalendarDays,
  MessageSquare
} from "lucide-react";
import { motion } from "framer-motion";

export default function MedLazerPro() {
  const doctors = [
    {
      name: "Dr. Otabek Mamatov",
      specialty: "Urolog",
      experience: "12 yil",
      degree: "tibbiyot fanlari doktori",
      image: "/images/doctors/otabek.jpg",
      phone: "+998 90 123 45 67",
      telegram: "@otabek_urolog"
    },
    {
      name: "Dr. Mohira Karimova",
      specialty: "Ginekolog",
      experience: "8 yil",
      degree: "katta shifokor",
      image: "/images/doctors/mohira.jpg",
      phone: "+998 91 765 43 21",
      telegram: "@mohira_ginekolog"
    },
    {
      name: "Dr. Jasur Bekmurodov",
      specialty: "Jarroh",
      experience: "15 yil",
      degree: "tibbiyot fanlari nomzodi",
      image: "/images/doctors/jasur.jpg",
      phone: "+998 93 111 22 33",
      telegram: "@jasur_jarroh"
    }
  ];

  const [diagnosisResult, setDiagnosisResult] = useState("");

  const services = [
    {
      title: "Urologiya",
      description: "Buyrak, siydik yo‘llari, prostata bilan bog‘liq davolovchi xizmatlar.",
      duration: "40-60 daqiqa",
      price: "150 000 UZS",
      doctors: ["Dr. Otabek Mamatov"],
      color: "blue"
    },
    {
      title: "Jarrohlik",
      description: "Minimal invaziv, laparoskopik va umumiy jarrohlik xizmatlari.",
      duration: "1.5 - 3 soat",
      price: "700 000 UZS dan boshlab",
      doctors: ["Dr. Jasur Bekmurodov"],
      color: "purple"
    },
    {
      title: "Ginekologiya",
      description: "Ayollar salomatligi va diagnostikasi bo‘yicha yuqori sifatli xizmatlar.",
      duration: "30-45 daqiqa",
      price: "120 000 UZS",
      doctors: ["Dr. Mohira Karimova"],
      color: "pink"
    },
    {
      title: "Proktologiya",
      description: "Ichki va tashqi gemorroy, anal yoriqlarni zamonaviy usullarda davolash.",
      duration: "30-60 daqiqa",
      price: "160 000 UZS",
      doctors: ["Dr. Jasur Bekmurodov"],
      color: "green"
    }
  ];

  const handleDiagnosis = (e) => {
    e.preventDefault();
    const selected = Array.from(e.target.symptoms.selectedOptions).map((o) => o.value);
    let result = "To‘liq check-up paketini tanlashingiz tavsiya etiladi.";
    if (selected.includes("Bel sohasida og‘riq") || selected.includes("Qovuqda achishish")) {
      result = "Urologik ko‘rik va ultratovush tekshiruvi tavsiya etiladi.";
    } else if (selected.includes("Ortiqcha qon ketishi (ayollarda)")) {
      result = "Ginekologik tekshiruv va laborator testlar zarur.";
    } else if (selected.includes("Ich ketishi yoki qorin og‘rig‘i")) {
      result = "Proktologik maslahat tavsiya etiladi.";
    }
    setDiagnosisResult(result);
  };

  return <div>{/* ... UI rendering continued */}</div>;
}
