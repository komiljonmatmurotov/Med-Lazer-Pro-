// Med Lazer Pro - Admin Panel Homepage (Dashboard + Doctor Profiles + Telegram Chat)
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Users,
  CalendarCheck,
  Stethoscope,
  Activity,
  Female,
  ShieldPlus,
  PlusCircle,
  BarChart,
  CalendarDays,
  MessageSquare
} from "lucide-react";
import { motion } from "framer-motion";

export default function MedLazerPro() {
  const doctors = [...]; // shortened for clarity
  const [diagnosisResult, setDiagnosisResult] = useState("");
  const services = [...]; // shortened for clarity

  const handleDiagnosis = (e) => {
    e.preventDefault();
    const selected = Array.from(e.target.symptoms.selectedOptions).map((o) => o.value);
    let result = "To‘liq check-up paketini tanlashingiz tavsiya etiladi.";
    if (selected.includes("Bel sohasida og‘riq") || selected.includes("Qovuqda achishish")) {
      result = "Urologik ko‘rik va ultratovush tekshiruvi tavsiya etiladi.";
    } else if (selected.includes("Ortiqcha qon ketishi (ayollarda)")) {
      result = "Ginekologik tekshiruv va laborator testlar zarur.";
    } else if (selected.includes("Ich ketishi yoki qorin og‘rig‘i")) {
      result = "Proktologik maslahat tavsiya etiladi.";
    }
    setDiagnosisResult(result);
  };

  return (
    <main className="min-h-screen bg-gray-100 p-6 grid gap-6">
      <motion.h1
        className="text-3xl font-bold text-gray-800"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Med Lazer Pro — Admin Panel
      </motion.h1>

      {/* Check-Up Tashxis Formasi */}
      <section className="bg-white rounded-xl shadow p-6 mt-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-700">Simptomlar asosida Check-Up tavsiyasi</h2>
        <form onSubmit={handleDiagnosis} className="space-y-4">
          <label className="block text-sm text-gray-600">
            Simptom(lar):
            <select name="symptoms" multiple className="w-full mt-1 p-2 border rounded">
              <option>Bel sohasida og‘riq</option>
              <option>Qon bosimi o‘zgarishi</option>
              <option>Ich ketishi yoki qorin og‘rig‘i</option>
              <option>Qovuqda achishish</option>
              <option>Ortiqcha qon ketishi (ayollarda)</option>
            </select>
          </label>
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Taxminiy tashxisni ko‘rish
          </button>
        </form>
        {diagnosisResult && (
          <div className="mt-4 p-4 bg-blue-100 border border-blue-300 rounded text-sm text-blue-800">
            <strong>Natija:</strong> {diagnosisResult}
          </div>
        )}
      </section>
    </main>
  );
}